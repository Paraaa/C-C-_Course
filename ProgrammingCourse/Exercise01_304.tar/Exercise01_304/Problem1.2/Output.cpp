#include <iostream>

using namespace std;

int main() {

  cout << "This is written to stdout" << endl;
  cerr << "This is written to stderr" << endl;

}
