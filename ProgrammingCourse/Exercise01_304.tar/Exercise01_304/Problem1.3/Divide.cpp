#include <iostream>

using namespace std;

int main() {
  
  double a, b;

  // ask user to enter two numbers and store values in a and b
  cout << "Enter two numbers: ";
  cin >> a >> b;

  // calculate a divided by b and print out result
  double x = a/b;
  cout << a << " divided by " << b << " is equal to " << x << endl;

}
